#!/usr/bin/env python3
"""Geofabrik Małopolskie OSM PBF -> bundled offline SQLite database.
Requires: pip install osmium. Stdlib-only for database/download/compression.
Usage: python tools/prepare_malopolska.py [--input existing.osm.pbf]
"""
import argparse
from collections import defaultdict
import gzip
import hashlib
import math
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import unicodedata
from urllib.request import Request, urlopen

GEOfABRIK = 'https://download.geofabrik.de/europe/poland/malopolskie-latest.osm.pbf'
HERE = Path(__file__).resolve().parents[1]
ASSET = HERE / 'app' / 'src' / 'main' / 'assets' / 'malopolska.db.gz'
ALLOWED = {'motorway', 'trunk', 'primary', 'secondary', 'tertiary', 'unclassified',
           'residential', 'living_street', 'service', 'road', 'track',
           'motorway_link', 'trunk_link', 'primary_link', 'secondary_link', 'tertiary_link'}
BANNED = {'private', 'no'}


def download(url, target):
    print('Pobieram:', url, flush=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    with urlopen(Request(url, headers={'User-Agent': 'PaczkiOffline/1.1 (OSM offline build)'}), timeout=90) as reply:
        with open(target, 'wb') as out:
            while True:
                b = reply.read(1024 * 1024)
                if not b: break
                out.write(b)
    if target.stat().st_size < 1_000_000:
        raise ValueError('Pobrany plik OSM jest podejrzanie mały.')
    try:
        with urlopen(Request(url+'.md5', headers={'User-Agent': 'PaczkiOffline/1.1'}), timeout=60) as reply:
            known = reply.read(300).decode('ascii').split()[0].lower()
        if len(known) == 32:
            h = hashlib.md5()
            with open(target, 'rb') as inp:
                for b in iter(lambda: inp.read(1024*1024), b''): h.update(b)
            if h.hexdigest() != known:
                raise ValueError('Suma kontrolna MD5 danych OSM nie zgadza się z Geofabrik.')
            print('Sprawdzono sumę kontrolną MD5.', flush=True)
    except ValueError:
        raise
    except Exception as ex:
        print('Nie udało się sprawdzić sumy MD5:', ex, file=sys.stderr)


def normalized(s):
    decomposed = unicodedata.normalize('NFD', (s or '').lower().replace('ł', 'l'))
    return ''.join(c for c in decomposed if unicodedata.category(c) != 'Mn').strip()


def distance2(lat, lon, place):
    return ((lat-place[1])*111_000)**2 + ((lon-place[2])*111_000*math.cos(math.radians(lat)))**2


class Writer:
    def __init__(self, filename):
        self.db = sqlite3.connect(filename)
        self.db.execute('PRAGMA journal_mode=OFF')
        self.db.execute('PRAGMA synchronous=OFF')
        self.db.execute('PRAGMA temp_store=MEMORY')
        self.db.executescript('''
            CREATE TABLE raw_addresses(id TEXT PRIMARY KEY, town TEXT, place TEXT,
                street TEXT, house TEXT, lat REAL, lon REAL);
            CREATE TABLE road_nodes(id INTEGER PRIMARY KEY, lat REAL, lon REAL);
            CREATE TABLE road_edges(source INTEGER, target INTEGER, meters REAL);
        ''')
        self.address_buf = []
        self.node_buf = []
        self.edge_buf = []
        self.places = []
        self.counts = [0, 0, 0]
        self.db.execute('BEGIN')

    def flush(self):
        if self.address_buf:
            self.db.executemany('INSERT OR IGNORE INTO raw_addresses VALUES(?,?,?,?,?,?,?)',self.address_buf)
            self.counts[0] += len(self.address_buf)
            self.address_buf.clear()
        if self.node_buf:
            self.db.executemany('INSERT OR IGNORE INTO road_nodes VALUES(?,?,?)',self.node_buf)
            self.counts[1] += len(self.node_buf)
            self.node_buf.clear()
        if self.edge_buf:
            self.db.executemany('INSERT INTO road_edges VALUES(?,?,?)',self.edge_buf)
            self.counts[2] += len(self.edge_buf)
            self.edge_buf.clear()

    def address(self, prefix, oid, tags, lat, lon):
        house = (tags.get('addr:housenumber', '') or '').strip()
        if not house: return
        self.address_buf.append((prefix+str(oid),
            (tags.get('addr:city', '') or '').strip(),
            (tags.get('addr:place', '') or '').strip(),
            (tags.get('addr:street', '') or '').strip(), house, lat, lon))
        if len(self.address_buf) >= 10000: self.flush()

    def node(self, oid, lat, lon, tags):
        if tags.get('place', '') in {'city','town','village','hamlet'} and tags.get('name'):
            self.places.append((tags.get('name'),lat,lon))
        if tags.get('addr:housenumber'): self.address('n',oid,tags,lat,lon)

    def way(self, oid, points, tags):
        if tags.get('addr:housenumber') and points:
            lat = sum(v[1] for v in points)/len(points)
            lon = sum(v[2] for v in points)/len(points)
            self.address('w',oid,tags,lat,lon)
        if tags.get('highway') not in ALLOWED: return
        if any(tags.get(k) in BANNED for k in ('access','motor_vehicle','vehicle')): return
        reverse = tags.get('oneway') == '-1'
        oneway = reverse or tags.get('oneway') in {'yes','true','1'} or tags.get('junction') == 'roundabout'
        for (na,la,loa), (nb,lb,lob) in zip(points, points[1:]):
            dlat=math.radians(lb-la); dlon=math.radians(lob-loa)
            a=math.sin(dlat/2)**2+math.cos(math.radians(la))*math.cos(math.radians(lb))*math.sin(dlon/2)**2
            meters = 6371000.0*2*math.atan2(math.sqrt(a),math.sqrt(max(0,1-a)))
            if meters < 0.01: continue
            self.node_buf.append((na,la,loa)); self.node_buf.append((nb,lb,lob))
            if not reverse: self.edge_buf.append((na,nb,meters))
            if reverse or not oneway: self.edge_buf.append((nb,na,meters))
            if len(self.edge_buf)>=20000: self.flush()

    def finish(self):
        self.flush()
        self.db.commit()
        print('Surowe adresy:', self.counts[0], 'węzły:',self.counts[1], 'krawędzie:',self.counts[2],flush=True)
        self.db.executescript('''
            CREATE TABLE addresses(id TEXT PRIMARY KEY, town TEXT NOT NULL,
                street TEXT, house TEXT, lat REAL, lon REAL, label TEXT, search TEXT);
        ''')
        grid=defaultdict(list)
        cell=0.05
        for p in self.places:
            grid[(math.floor(p[1]/cell),math.floor(p[2]/cell))].append(p)
        print('Nazwy miejscowości z OSM:',len(self.places),flush=True)
        def nearest(lat,lon):
            i,j = math.floor(lat/cell),math.floor(lon/cell)
            best=None; ds=15000**2
            for radius in range(4):
                for x in range(i-radius,i+radius+1):
                    for y in range(j-radius,j+radius+1):
                        if max(abs(x-i),abs(y-j))!=radius: continue
                        for p in grid.get((x,y),()):
                            d=distance2(lat,lon,p)
                            if d<ds: best=p[0]; ds=d
            return best or ''
        # Avoid loading full addresses in memory; convert in batches.
        incoming=self.db.execute('SELECT id,town,place,street,house,lat,lon FROM raw_addresses')
        out=[]; shown=0
        self.db.execute('BEGIN')
        for oid,city,place,street,house,lat,lon in incoming:
            town=place or city or nearest(lat,lon)
            if not town: continue
            label=(street+' '+house+', '+town) if street and normalized(street)!=normalized(town) else (town+' '+house)
            out.append((oid,town,street,house,lat,lon,label,normalized(label)))
            if len(out)>=10000:
                self.db.executemany('INSERT INTO addresses VALUES (?,?,?,?,?,?,?,?)',out)
                shown+=len(out)
                out=[]
        if out:
            self.db.executemany('INSERT INTO addresses VALUES (?,?,?,?,?,?,?,?)',out)
            shown+=len(out)
        self.db.commit()
        self.db.executescript('''
            DROP TABLE raw_addresses;
            CREATE INDEX addresses_town ON addresses(town COLLATE NOCASE);
            CREATE INDEX addresses_search ON addresses(town COLLATE NOCASE, search);
            CREATE INDEX road_lat_lon ON road_nodes(lat,lon);
            CREATE INDEX road_edges_source ON road_edges(source);
            CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            INSERT INTO metadata VALUES('source','Geofabrik OpenStreetMap - Małopolskie');
            INSERT INTO metadata VALUES('format_version','1');
        ''')
        # SQLite VACUUM shrinks deleted staging data before packaging.
        self.db.execute('VACUUM')
        print('Adresy gotowe:',shown,'baza SQLite:',os.path.getsize(self.db.execute('PRAGMA database_list').fetchone()[2]),flush=True)
        self.db.close()


def from_pbf(inp, writer):
    try:
        import osmium
    except ImportError as e:
        raise SystemExit('Zainstaluj: python -m pip install osmium') from e
    class Handler(osmium.SimpleHandler):
        def node(self, n):
            if n.location.valid():
                writer.node(n.id,n.location.lat,n.location.lon,{x.k:x.v for x in n.tags})
        def way(self, w):
            tags={x.k:x.v for x in w.tags}
            if not tags.get('addr:housenumber') and tags.get('highway') not in ALLOWED: return
            points=[]
            for n in w.nodes:
                if n.location.valid(): points.append((n.ref,n.location.lat,n.location.lon))
            writer.way(w.id,points,tags)
    Handler().apply_file(str(inp), locations=True, idx='flex_mem')


def from_xml(inp, writer):
    """Test path for tiny OSM XML fixture. Production uses PBF/osmium."""
    from xml.etree.ElementTree import iterparse
    nodes={}; roads=[]
    for _,elem in iterparse(inp, events=('end',)):
        if elem.tag=='node':
            lat=float(elem.attrib['lat']);lon=float(elem.attrib['lon']);oid=int(elem.attrib['id'])
            nodes[oid]=(lat,lon)
            writer.node(oid,lat,lon,{t.get('k'):t.get('v') for t in elem.findall('tag')})
            elem.clear()
        elif elem.tag=='way':
            tags={t.get('k'):t.get('v') for t in elem.findall('tag')}
            pts=[(int(n.get('ref')), *nodes[int(n.get('ref'))]) for n in elem.findall('nd') if int(n.get('ref')) in nodes]
            writer.way(int(elem.attrib['id']),pts,tags)
            elem.clear()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',help='Użyj już pobranego pliku .osm.pbf (lub małego testowego .osm)')
    ap.add_argument('--output',default=str(ASSET),help='Lokalizacja gotowej bazy .db.gz')
    args=ap.parse_args()
    with tempfile.TemporaryDirectory(prefix='paczki-osm-') as temp:
        temp=Path(temp)
        inp=Path(args.input) if args.input else temp/'malopolskie-latest.osm.pbf'
        if not args.input: download(GEOfABRIK,inp)
        dbpath=temp/'malopolska.db'
        writer=Writer(dbpath)
        if inp.suffix.lower()=='.osm': from_xml(inp,writer)
        else: from_pbf(inp,writer)
        writer.finish()
        output=Path(args.output)
        output.parent.mkdir(parents=True,exist_ok=True)
        with open(dbpath,'rb') as source, gzip.open(output,'wb',compresslevel=6) as zipped:
            for b in iter(lambda: source.read(1024*1024),b''): zipped.write(b)
        print('Gotowy pakiet offline:',output,output.stat().st_size,'B',flush=True)


if __name__=='__main__':main()
