package pl.paczki.offline;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import pl.paczki.offline.core.Address;
import pl.paczki.offline.core.RoadGraph;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Baza Małopolski w APK: kopiowana na urządzenie tylko przy pierwszym uruchomieniu. */
public final class OfflineDatabase implements AutoCloseable {
    private final SQLiteDatabase database;

    private OfflineDatabase(SQLiteDatabase database) { this.database=database; }

    public static OfflineDatabase open(Context context) throws Exception {
        File target=new File(context.getFilesDir(),"malopolska.db");
        if (!target.exists() || target.length()<1000) {
            File temp=new File(context.getFilesDir(),"malopolska.tmp");
            try (InputStream in=new GZIPInputStream(new BufferedInputStream(context.getAssets().open("malopolska.db.gz")));
                 BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(temp))) {
                byte[] buffer=new byte[65536]; int n;
                while ((n=in.read(buffer))!=-1) out.write(buffer,0,n);
            } catch(Exception e) { temp.delete(); throw e; }
            if (target.exists() && !target.delete()) throw new IllegalStateException("Nie można wymienić bazy adresów.");
            if (!temp.renameTo(target)) throw new IllegalStateException("Nie można zainstalować bazy adresów.");
        }
        SQLiteDatabase db=SQLiteDatabase.openDatabase(target.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        try (Cursor c=db.rawQuery("SELECT value FROM metadata WHERE key='format_version'",null)) {
            if (!c.moveToFirst() || !"1".equals(c.getString(0))) {
                db.close(); throw new SQLiteException("Nieobsługiwana wersja bazy.");
            }
        }
        return new OfflineDatabase(db);
    }

    public List<String> towns() {
        List<String> out=new ArrayList<>();
        try(Cursor c=database.rawQuery("SELECT DISTINCT town FROM addresses ORDER BY town COLLATE NOCASE",null)) {
            while(c.moveToNext()) out.add(c.getString(0));
        }
        return out;
    }

    public List<Address> search(String town1,String town2,String text) {
        List<Address> out=new ArrayList<>();
        String term=Address.normalized(text);
        // Wszystkie wartości użytkownika są wiązane przez SQLite; brak składania SQL z tekstem wyszukania.
        String sql="SELECT id,town,street,house,lat,lon FROM addresses WHERE (town=? COLLATE NOCASE OR town=? COLLATE NOCASE) "
            +"AND search LIKE ? ESCAPE '\\' ORDER BY street COLLATE NOCASE, house LIMIT 50";
        term=term.replace("\\","\\\\").replace("%","\\%").replace("_","\\_");
        try(Cursor c=database.rawQuery(sql,new String[]{town1,town2,"%"+term+"%"})) {
            while(c.moveToNext()) out.add(readAddress(c));
        }
        return out;
    }

    public Address addressById(String id) {
        try(Cursor c=database.rawQuery("SELECT id,town,street,house,lat,lon FROM addresses WHERE id=?",new String[]{id})) {
            return c.moveToFirst()?readAddress(c):null;
        }
    }
    private static Address readAddress(Cursor c) {
        return new Address(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5));
    }

    /** Wczytaj wyłącznie drogi w okolicy paczek, nie całą Małopolskę do RAM. */
    public RoadGraph graphFor(List<Address> stops) {
        RoadGraph graph=new RoadGraph();
        if (stops.isEmpty()) return graph;
        // Dwa odległe miasta: wczytujemy osobne lokalne wycinki, zamiast
        // przypadkowo załadować cały region (połączenie między nimi będzie przybliżone).
        Map<String,double[]> groups=new LinkedHashMap<>();
        for(Address a:stops) {
            double[] r=groups.get(a.town);
            if(r==null){r=new double[]{90,-90,180,-180};groups.put(a.town,r);}
            r[0]=Math.min(r[0],a.lat); r[1]=Math.max(r[1],a.lat);
            r[2]=Math.min(r[2],a.lon); r[3]=Math.max(r[3],a.lon);
        }
        List<String> clauses=new ArrayList<>();
        List<String> argList=new ArrayList<>();
        for(double[] r:groups.values()) {
            // Około 10 km wokół każdej miejscowości i jej paczek.
            clauses.add("(lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?)");
            argList.add(Double.toString(r[0]-0.09));argList.add(Double.toString(r[1]+0.09));
            argList.add(Double.toString(r[2]-0.14));argList.add(Double.toString(r[3]+0.14));
        }
        String query=String.join(" OR ",clauses);
        String[] args=argList.toArray(new String[0]);
        Map<Long,RoadGraph.Coordinate> nodes=new HashMap<>();
        try(Cursor c=database.rawQuery("SELECT id,lat,lon FROM road_nodes WHERE "+query+" LIMIT 130001",args)) {
            while(c.moveToNext()) {
                nodes.put(c.getLong(0),new RoadGraph.Coordinate(c.getDouble(1),c.getDouble(2)));
            }
        }
        // Zamiast ryzykować błąd pamięci na starszym telefonie, użyj przybliżenia
        // odległości, które planer oznacza jako niepewne.
        if(nodes.size()>130000) return graph;
        String sql="SELECT e.source,e.target FROM road_edges e WHERE e.source IN "
                 +"(SELECT id FROM road_nodes WHERE "+query+")";
        try(Cursor c=database.rawQuery(sql,args)) {
            while(c.moveToNext()) {
                long from=c.getLong(0),to=c.getLong(1);
                RoadGraph.Coordinate a=nodes.get(from),b=nodes.get(to);
                if(a!=null && b!=null) graph.addSegment(from,a,to,b,true,false);
            }
        }
        return graph;
    }

    @Override public void close() {database.close();}
}
