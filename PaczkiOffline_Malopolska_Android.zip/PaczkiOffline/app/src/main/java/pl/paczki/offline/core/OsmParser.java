package pl.paczki.offline.core;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParserFactory;
import java.io.InputStream;
import java.util.*;

/** Import zwykłego pliku OpenStreetMap XML (*.osm), bez połączenia sieciowego. */
public final class OsmParser {
    private OsmParser() {}

    public static final class Data {
        public final List<Address> addresses;
        public final RoadGraph graph;
        public Data(List<Address> addresses, RoadGraph graph) { this.addresses=addresses; this.graph=graph; }
        public List<String> towns() {
            Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            for (Address a : addresses) names.add(a.town);
            return new ArrayList<>(names);
        }
    }
    private static final class Place {
        final String name; final double lat,lon;
        Place(String name, double lat,double lon) { this.name=name; this.lat=lat; this.lon=lon; }
    }
    private static final class RawAddress {
        String id, house, street, town, place;
        double lat,lon;
    }
    private static final class Way {
        long id;
        List<Long> refs = new ArrayList<>();
        Map<String,String> tags = new HashMap<>();
    }

    public static Data read(InputStream input) throws Exception {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(false);
        // Nie każdy parser Androida rozpoznaje wszystkie zabezpieczające funkcje SAX.
        try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        try { factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true); } catch (Exception ignored) {}
        Handler handler = new Handler();
        factory.newSAXParser().parse(input, handler);
        return handler.finish();
    }

    private static final class Handler extends DefaultHandler {
        @Override public InputSource resolveEntity(String publicId, String systemId) {
            return new InputSource(new java.io.StringReader(""));
        }
        final Map<Long,RoadGraph.Coordinate> coordinates = new HashMap<>();
        final List<Place> places = new ArrayList<>();
        final List<RawAddress> rawAddresses = new ArrayList<>();
        final List<Way> roadWays = new ArrayList<>();
        final List<Way> addressWays = new ArrayList<>();
        long nodeId;
        double nodeLat,nodeLon;
        boolean onNode = false;
        Map<String,String> nodeTags;
        Way way;

        @Override public void startElement(String uri, String localName, String qName, Attributes a) throws SAXException {
            switch (qName) {
                case "node":
                    onNode = true;
                    nodeId = asLong(a.getValue("id"));
                    nodeLat = asDouble(a.getValue("lat"));
                    nodeLon = asDouble(a.getValue("lon"));
                    nodeTags = new HashMap<>();
                    break;
                case "way":
                    way = new Way(); way.id=asLong(a.getValue("id"));
                    break;
                case "nd":
                    if (way != null) way.refs.add(asLong(a.getValue("ref")));
                    break;
                case "tag":
                    String key=a.getValue("k"), val=a.getValue("v");
                    if (key != null && val != null) {
                        if (way != null) way.tags.put(key,val);
                        else if (onNode) nodeTags.put(key,val);
                    }
                    break;
                default: break;
            }
        }
        @Override public void endElement(String uri,String localName,String qName) {
            switch(qName) {
                case "node":
                    coordinates.put(nodeId,new RoadGraph.Coordinate(nodeLat,nodeLon));
                    String pt=nodeTags.get("place");
                    if (pt != null && Arrays.asList("city","town","village","hamlet","suburb").contains(pt)
                            && valid(nodeTags.get("name"))) {
                        places.add(new Place(nodeTags.get("name"),nodeLat,nodeLon));
                    }
                    if (valid(nodeTags.get("addr:housenumber"))) {
                        rawAddresses.add(create("n:"+nodeId,nodeTags,nodeLat,nodeLon));
                    }
                    onNode=false; nodeTags=null;
                    break;
                case "way":
                    if (way != null) {
                        if (valid(way.tags.get("highway")) && isDrivable(way.tags)) roadWays.add(way);
                        if (valid(way.tags.get("addr:housenumber"))) addressWays.add(way);
                    }
                    way=null;
                    break;
                default: break;
            }
        }
        private RawAddress create(String id, Map<String,String> tags, double lat,double lon) {
            RawAddress a=new RawAddress();
            a.id=id; a.lat=lat; a.lon=lon;
            a.house=tags.getOrDefault("addr:housenumber","").trim();
            a.street=tags.getOrDefault("addr:street","").trim();
            a.place=tags.getOrDefault("addr:place","").trim();
            a.town=tags.getOrDefault("addr:city","").trim();
            return a;
        }
        private Data finish() {
            // Nie zakładamy konkretnej kolejności elementów w pliku XML.
            for (Way w:addressWays) {
                double lat=0,lon=0; int count=0;
                for (long ref:new HashSet<>(w.refs)) {
                    RoadGraph.Coordinate c=coordinates.get(ref);
                    if (c!=null) { lat+=c.lat; lon+=c.lon; count++; }
                }
                if (count>0) rawAddresses.add(create("w:"+w.id,w.tags,lat/count,lon/count));
            }
            RoadGraph graph=new RoadGraph();
            for (Way way:roadWays) {
                boolean isReverse = "-1".equals(way.tags.get("oneway"));
                boolean isOneWay = isReverse || "yes".equals(way.tags.get("oneway"))
                        || "true".equals(way.tags.get("oneway")) || "1".equals(way.tags.get("oneway"))
                        || "roundabout".equals(way.tags.get("junction"));
                for (int i=1;i<way.refs.size();i++) {
                    long a=way.refs.get(i-1), b=way.refs.get(i);
                    RoadGraph.Coordinate p=coordinates.get(a), q=coordinates.get(b);
                    if (p==null || q==null) continue;
                    graph.addSegment(a,p,b,q,!isReverse,!isOneWay || isReverse);
                }
            }
            List<Address> out=new ArrayList<>();
            Set<String> dedupe=new HashSet<>();
            for (RawAddress a:rawAddresses) {
                String town= valid(a.place) ? a.place : a.town;
                if (!valid(town)) town=nearestTown(a.lat,a.lon);
                if (!valid(town)) town="(bez miejscowości)";
                String street=a.street;
                if (!valid(street) && valid(a.place) && !Address.normalized(a.place).equals(Address.normalized(town)))
                    street=a.place;
                String labelKey=Address.normalized(town)+"|"+Address.normalized(street)+"|"+Address.normalized(a.house);
                if (dedupe.add(labelKey)) out.add(new Address(a.id,town,street,a.house,a.lat,a.lon));
            }
            out.sort(Comparator.comparing((Address a) -> Address.normalized(a.town))
                    .thenComparing(a -> Address.normalized(a.street))
                    .thenComparing(a -> houseSort(a.house)));
            return new Data(out,graph);
        }
        private String nearestTown(double lat,double lon) {
            String best=""; double min=Double.POSITIVE_INFINITY;
            for (Place p:places) {
                double d=RoadGraph.meters(lat,lon,p.lat,p.lon);
                if (d<min) { min=d; best=p.name; }
            }
            // Nie przypisuj miejscowości, jeśli brak pobliskiego punktu osady.
            return min<=15000 ? best : "";
        }
    }
    private static String houseSort(String house) {
        // Zamienia 2, 9, 10 na poprawne porządkowanie leksykograficzne.
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("^(\\d+)(.*)$").matcher(house);
        if (!m.matches()) return house;
        try { return String.format(java.util.Locale.ROOT,"%010d%s",Long.parseLong(m.group(1)),m.group(2)); }
        catch (NumberFormatException e) { return house; }
    }
    private static long asLong(String value) { try { return Long.parseLong(value); } catch(Exception e) { return 0; } }
    private static double asDouble(String value) { try { return Double.parseDouble(value); } catch(Exception e) { return 0; } }
    private static boolean valid(String s) { return s!=null && !s.trim().isEmpty(); }
    private static boolean isDrivable(Map<String,String> tags) {
        String type=tags.get("highway");
        Set<String> allowed=new HashSet<>(Arrays.asList("motorway","trunk","primary","secondary","tertiary",
                "unclassified","residential","living_street","service","road","track",
                "motorway_link","trunk_link","primary_link","secondary_link","tertiary_link"));
        if (!allowed.contains(type)) return false;
        if ("no".equals(tags.get("motor_vehicle")) || "private".equals(tags.get("motor_vehicle"))
                || "no".equals(tags.get("vehicle")) || "private".equals(tags.get("vehicle"))) return false;
        if ("no".equals(tags.get("access")) || "private".equals(tags.get("access"))) return false;
        return true;
    }
}
