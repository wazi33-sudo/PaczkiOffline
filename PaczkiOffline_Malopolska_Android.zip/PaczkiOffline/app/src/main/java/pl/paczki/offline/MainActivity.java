package pl.paczki.offline;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import pl.paczki.offline.core.Address;
import pl.paczki.offline.core.RoutePlanner;
import pl.paczki.offline.core.RoadGraph;

import java.util.*;

/** Jeden ekran, offline: baza adresów Małopolski jest już wbudowana w aplikację. */
public final class MainActivity extends Activity {
    private static final String NONE="— brak —";
    private final LinkedHashMap<String,Address> stops=new LinkedHashMap<>();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private OfflineDatabase db;
    private SharedPreferences prefs;
    private AutoCompleteTextView townOne,townTwo;
    private Spinner firstSpinner,lastSpinner;
    private TextView status,foundTitle,selectedTitle,resultTitle;
    private EditText search;
    private LinearLayout foundRows,selectedRows,resultRows;
    private Button planButton;
    private String firstId,lastId,cityOne="",cityTwo=NONE;
    private boolean changingTowns=false,changingStops=false,busy=true;
    private List<String> townNames=Collections.emptyList();
    private int searchToken=0;
    private Runnable pendingSearch;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs=getSharedPreferences("paczki_malopolska",MODE_PRIVATE);
        buildUi(); setStatus("Przygotowuję bazę adresów Małopolski… (pierwsze uruchomienie może potrwać)");
        new Thread(() -> {
            try {
                OfflineDatabase loaded=OfflineDatabase.open(getApplicationContext());
                List<String> towns=loaded.towns();
                if(towns.isEmpty()) throw new IllegalStateException("Brak miejscowości w bazie adresów.");
                runOnUiThread(() -> {
                    db=loaded;busy=false;
                    setupTowns(towns);restoreStops();rebuildSelected();scheduleSearch();refreshEnabled();
                    setStatus("Gotowe. Dane Małopolski zapisane offline. Wybierz miejscowość i dodaj paczki.");
                });
            } catch(Exception ex) {
                runOnUiThread(() -> {
                    busy=false;refreshEnabled();
                    failure("Nie można odczytać wbudowanej bazy Małopolski: "+ex.getMessage());
                });
            }
        }).start();
    }

    private void buildUi() {
        int pad=dp(16);
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(247,249,251));
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setPadding(pad,dp(22),pad,dp(30));
        scroll.addView(root);setContentView(scroll);

        TextView title=text("PACZKI OFFLINE",24,true);
        title.setTextColor(Color.rgb(19,49,81));root.addView(title);
        TextView subtitle=text("MAŁOPOLSKA • adresy OpenStreetMap",13,false);
        subtitle.setTextColor(Color.DKGRAY);root.addView(subtitle);
        status=text("",13,false); status.setTextColor(Color.DKGRAY);
        marginTop(root,status,dp(12));

        marginTop(root,text("1. Wybierz 1 lub 2 miejscowości",17,true),dp(24));
        root.addView(label("Miejscowość 1"));
        townOne=townInput("Wpisz miejscowość...");root.addView(townOne);
        root.addView(label("Miejscowość 2 (opcjonalnie)"));
        townTwo=townInput("Druga miejscowość lub puste pole");root.addView(townTwo);
        townOne.setOnItemClickListener((p,v,pos,id)->townChanged());
        townTwo.setOnItemClickListener((p,v,pos,id)->townChanged());
        townOne.setOnFocusChangeListener((v,focused)->{if(!focused)townChanged();});
        townTwo.setOnFocusChangeListener((v,focused)->{if(!focused)townChanged();});

        marginTop(root,text("2. Dodaj adresy paczek",17,true),dp(20));
        search=new EditText(this);search.setTextSize(16);search.setSingleLine(true);
        search.setHint("Ulica lub numer domu…");search.setPadding(dp(10),dp(9),dp(10),dp(9));
        root.addView(search);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){scheduleSearch();}
            @Override public void afterTextChanged(Editable e){}
        });
        foundTitle=text("Wybierz miejscowość",13,false);
        marginTop(root,foundTitle,dp(6));
        foundRows=new LinearLayout(this);foundRows.setOrientation(LinearLayout.VERTICAL);
        root.addView(foundRows);

        LinearLayout selectedHead=new LinearLayout(this);
        selectedHead.setOrientation(LinearLayout.HORIZONTAL);selectedHead.setGravity(Gravity.CENTER_VERTICAL);
        selectedTitle=text("Wybrane paczki (0)",17,true);
        selectedHead.addView(selectedTitle,new LinearLayout.LayoutParams(0,-2,1));
        Button clear=button("Wyczyść",false);selectedHead.addView(clear);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Wyczyścić listę?")
            .setMessage("Usunąć adresy wszystkich paczek z listy?")
            .setNegativeButton("Anuluj",null)
            .setPositiveButton("Wyczyść",(d,w)->{
                stops.clear();firstId=null;lastId=null;persist();rebuildSelected();scheduleSearch();clearResult();
            }).show());
        marginTop(root,selectedHead,dp(20));
        selectedRows=new LinearLayout(this);selectedRows.setOrientation(LinearLayout.VERTICAL);root.addView(selectedRows);

        marginTop(root,text("3. Pierwszy i ostatni adres",17,true),dp(21));
        root.addView(label("Pierwsza paczka"));
        firstSpinner=new Spinner(this);root.addView(firstSpinner);
        root.addView(label("Ostatnia paczka"));
        lastSpinner=new Spinner(this);root.addView(lastSpinner);
        onSpinner(firstSpinner,()->{
            if(changingStops || stops.isEmpty()) return;
            int index=firstSpinner.getSelectedItemPosition();
            if(index>=0 && index<stops.size()) {
                firstId=new ArrayList<>(stops.keySet()).get(index);persist();clearResult();
            }
        });
        onSpinner(lastSpinner,()->{
            if(changingStops || stops.isEmpty()) return;
            int index=lastSpinner.getSelectedItemPosition();
            if(index>=0 && index<stops.size()) {
                lastId=new ArrayList<>(stops.keySet()).get(index);persist();clearResult();
            }
        });

        planButton=button("UŁÓŻ PACZKI",true);
        marginTop(root,planButton,dp(24));
        planButton.setOnClickListener(v -> calculate());
        resultTitle=text("",17,true);marginTop(root,resultTitle,dp(20));
        resultRows=new LinearLayout(this);resultRows.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultRows);
        TextView license=text("© współtwórcy OpenStreetMap • ODbL\nopenstreetmap.org/copyright",12,false);
        license.setTextColor(Color.GRAY);license.setGravity(Gravity.CENTER);
        marginTop(root,license,dp(32));
        refreshEnabled();
    }

    private AutoCompleteTextView townInput(String hint) {
        AutoCompleteTextView input=new AutoCompleteTextView(this);
        input.setTextSize(16);input.setSingleLine(true);input.setThreshold(1);
        input.setHint(hint);input.setPadding(dp(10),dp(10),dp(10),dp(10));
        input.setOnClickListener(v->input.showDropDown());
        return input;
    }
    private String exactTown(String value) {
        for(String name:townNames) if(Address.normalized(name).equals(Address.normalized(value)))return name;
        return null;
    }
    private void setupTowns(List<String> towns) {
        changingTowns=true;townNames=new ArrayList<>(towns);
        ArrayList<String> second=new ArrayList<>();second.add(NONE);second.addAll(towns);
        townOne.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,towns));
        townTwo.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,second));
        String savedOne=exactTown(prefs.getString("town1",""));
        String savedTwo=exactTown(prefs.getString("town2",""));
        cityOne=savedOne==null?towns.get(0):savedOne;
        cityTwo=savedTwo==null || cityOne.equals(savedTwo)?NONE:savedTwo;
        townOne.setText(cityOne,false);townTwo.setText(cityTwo,false);
        changingTowns=false;
    }
    private void townChanged() {
        if(changingTowns || db==null)return;
        String a=exactTown(townOne.getText().toString());
        String rawTwo=townTwo.getText().toString().trim();
        String b=rawTwo.isEmpty() || rawTwo.equals(NONE)?NONE:exactTown(rawTwo);
        if(a==null) {setStatus("Wybierz pierwszą miejscowość z podpowiedzi.");return;}
        if(b==null) {setStatus("Wybierz drugą miejscowość z podpowiedzi lub pozostaw pustą.");return;}
        if(a.equals(b))b=NONE;
        if(a.equals(cityOne) && b.equals(cityTwo))return;
        cityOne=a;cityTwo=b;
        townOne.setText(cityOne,false);townTwo.setText(cityTwo,false);
        stops.values().removeIf(x->!allowed(x));
        if(!stops.containsKey(firstId))firstId=null;
        if(!stops.containsKey(lastId))lastId=null;
        persist();rebuildSelected();scheduleSearch();clearResult();
        setStatus("Wybrano miejscowości: "+cityOne+(cityTwo.equals(NONE)?"":" i "+cityTwo));
    }
    private boolean allowed(Address a) {
        return a.town.equalsIgnoreCase(cityOne) || (!cityTwo.equals(NONE) && a.town.equalsIgnoreCase(cityTwo));
    }

    private void restoreStops() {
        stops.clear();
        for(String id:prefs.getString("stops","").split(",")) {
            if(id.isEmpty())continue;
            Address a=db.addressById(id);
            if(a!=null && allowed(a))stops.put(id,a);
        }
        firstId=prefs.getString("first",null);
        lastId=prefs.getString("last",null);
    }
    private void persist() {
        prefs.edit().putString("stops",String.join(",",stops.keySet()))
            .putString("first",firstId).putString("last",lastId)
            .putString("town1",cityOne).putString("town2",cityTwo).apply();
    }
    private void scheduleSearch() {
        if(foundRows==null)return;
        final int token=++searchToken;
        if(pendingSearch!=null)ui.removeCallbacks(pendingSearch);
        if(db==null || busy){foundTitle.setText("Przygotowuję dane adresowe…");return;}
        String one=cityOne,two=cityTwo,term=search.getText().toString();
        pendingSearch=()->new Thread(()->{
            try {
                List<Address> matching=db.search(one,two,term);
                runOnUiThread(()->{if(token==searchToken) showFound(matching);});
            } catch(Exception ex) {
                runOnUiThread(()->{if(token==searchToken)setStatus("Błąd wyszukiwania: "+ex.getMessage());});
            }
        }).start();
        ui.postDelayed(pendingSearch,180);
    }
    private void showFound(List<Address> addresses) {
        foundRows.removeAllViews();int shown=0;
        for(Address a:addresses) {
            if(stops.containsKey(a.id))continue;
            if(++shown>25)break;
            Button add=button("+  "+a.label(),false);
            add.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);add.setTextSize(14);
            foundRows.addView(add);
            add.setOnClickListener(v->{
                if(stops.size()>=250) {failure("Maksymalnie 250 adresów na trasie.");return;}
                stops.put(a.id,a);
                if(firstId==null)firstId=a.id;
                if(lastId==null || lastId.equals(firstId))lastId=a.id;
                search.setText("");persist();rebuildSelected();scheduleSearch();clearResult();
            });
        }
        foundTitle.setText(shown==0?"Brak innych adresów. Sprawdź nazwę lub numer.":
            "Wyniki: "+Math.min(shown,25)+(shown>25?" (wpisz dokładniejszy adres)":""));
    }
    private void rebuildSelected() {
        if(selectedRows==null)return;
        selectedRows.removeAllViews();selectedTitle.setText("Wybrane paczki ("+stops.size()+")");
        List<Address> items=new ArrayList<>(stops.values());
        if(items.isEmpty())selectedRows.addView(label("Dotknij adresu powyżej, aby dodać paczkę."));
        int max=Math.min(items.size(),20);
        for(int i=0;i<max;i++) {
            Address a=items.get(i);
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
            TextView text=text((i+1)+". "+a.label(),14,false);
            text.setPadding(dp(4),dp(9),dp(4),dp(9));
            row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
            Button del=button("Usuń",false);row.addView(del);
            del.setOnClickListener(v->{
                stops.remove(a.id);
                if(a.id.equals(firstId))firstId=null;
                if(a.id.equals(lastId))lastId=null;
                persist();rebuildSelected();scheduleSearch();clearResult();
            });
            selectedRows.addView(row);
        }
        if(items.size()>max)selectedRows.addView(label("… oraz "+(items.size()-max)+" kolejnych adresów."));
        changingStops=true;
        List<String> labels=new ArrayList<>();
        for(Address a:items)labels.add(a.label());
        spinnerItems(firstSpinner,labels);spinnerItems(lastSpinner,labels);
        if(!items.isEmpty()) {
            if(!stops.containsKey(firstId))firstId=items.get(0).id;
            if(!stops.containsKey(lastId))lastId=items.get(items.size()-1).id;
            firstSpinner.setSelection(new ArrayList<>(stops.keySet()).indexOf(firstId));
            lastSpinner.setSelection(new ArrayList<>(stops.keySet()).indexOf(lastId));
        }else {firstId=null;lastId=null;}
        changingStops=false;
        refreshEnabled();
    }

    private void calculate() {
        if(busy || db==null || stops.size()<2)return;
        if(firstId==null || lastId==null || firstId.equals(lastId)){
            failure("Wybierz dwa różne adresy jako pierwszy i ostatni punkt.");return;
        }
        List<Address> items=new ArrayList<>(stops.values());
        String first=firstId,last=lastId;
        busy=true;refreshEnabled();setStatus("Układam kolejność paczek po drogach Małopolski…");
        new Thread(()->{
            try {
                RoadGraph graph=db.graphFor(items);
                RoutePlanner.Result route=RoutePlanner.plan(items,first,last,graph);
                runOnUiThread(()->{
                    busy=false;refreshEnabled();showResult(route,graph.size());
                });
            }catch(Exception ex){runOnUiThread(()->{busy=false;refreshEnabled();failure("Błąd układania: "+ex.getMessage());});}
        }).start();
    }
    private void showResult(RoutePlanner.Result route,int roadNodes) {
        resultRows.removeAllViews();resultTitle.setText("KOLEJNOŚĆ DORĘCZEŃ");
        resultRows.addView(label("Pakuj paczki od KOŃCA poniższej listy — ostatnie dostawy najgłębiej."));
        for(int i=0;i<route.ordered.size();i++) {
            Address a=route.ordered.get(i);
            String no=i==0?"START":(i==route.ordered.size()-1?"KONIEC":String.valueOf(i+1));
            TextView t=text(no+"  •  "+a.label(),16,i==0 || i==route.ordered.size()-1);
            t.setPadding(dp(9),dp(12),dp(9),dp(12));
            if(i%2==0)t.setBackgroundColor(Color.rgb(234,241,247));
            resultRows.addView(t);
        }
        if(route.usedFallback) {
            setStatus("Ułożono "+route.ordered.size()+" adresów. Uwaga: "+route.disconnectedLegs+
                " odcinków policzono w przybliżeniu (brak pełnego połączenia dróg). Zweryfikuj trasę.");
        }else{
            setStatus("Ułożono "+route.ordered.size()+" adresów • orientacyjnie "+
                String.format(Locale.forLanguageTag("pl-PL"),"%.1f",route.estimatedMeters/1000.0)+
                " km. To propozycja kolejności, nie nawigacja.");
        }
    }
    private void clearResult(){if(resultRows!=null)resultRows.removeAllViews();if(resultTitle!=null)resultTitle.setText("");}
    private void failure(String msg){setStatus(msg);new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK",null).show();}
    private void refreshEnabled(){if(planButton!=null)planButton.setEnabled(!busy && db!=null && stops.size()>=2);}
    private void setStatus(String s){if(status!=null)status.setText(s);}
    private void spinnerItems(Spinner spin,List<String> names) {
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
    }
    private interface Changed {void changed();}
    private void onSpinner(Spinner spin,Changed callback) {
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){callback.changed();}
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
    }
    private TextView text(String label,int size,boolean bold){
        TextView v=new TextView(this);v.setText(label);v.setTextSize(size);v.setTextColor(Color.rgb(31,43,57));
        if(bold)v.setTypeface(null,Typeface.BOLD);
        return v;
    }
    private TextView label(String s){TextView v=text(s,13,false);v.setPadding(dp(2),dp(11),0,dp(5));return v;}
    private Button button(String s,boolean primary) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextSize(primary?17:14);
        b.setTextColor(primary?Color.WHITE:Color.rgb(19,49,81));
        GradientDrawable d=new GradientDrawable();d.setCornerRadius(dp(10));
        d.setColor(primary?Color.rgb(26,90,156):Color.rgb(231,238,244));b.setBackground(d);
        b.setPadding(dp(12),dp(9),dp(12),dp(9));b.setMinHeight(dp(46));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(0,dp(4),dp(4),0);b.setLayoutParams(p);
        return b;
    }
    private void marginTop(LinearLayout p,View v,int gap){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=gap;p.addView(v,lp);
    }
    private int dp(float val){return (int)(getResources().getDisplayMetrics().density*val+0.5f);}
    @Override protected void onDestroy(){if(pendingSearch!=null)ui.removeCallbacks(pendingSearch);super.onDestroy();}
}
