package pl.paczki.offline.core;

import java.util.*;

/** Kolejność dostaw z ustalonym początkiem i końcem; Dijkstra + 2-opt. */
public final class RoutePlanner {
    private RoutePlanner() {}

    public static final class Result {
        public final List<Address> ordered;
        public final double estimatedMeters;
        public final boolean usedFallback;
        public final int disconnectedLegs;
        Result(List<Address> ordered,double estimatedMeters, boolean usedFallback, int disconnectedLegs) {
            this.ordered=ordered; this.estimatedMeters=estimatedMeters;
            this.usedFallback=usedFallback; this.disconnectedLegs=disconnectedLegs;
        }
    }

    public static Result plan(List<Address> stops, String firstId, String lastId, RoadGraph graph) {
        if (stops.size()<2) throw new IllegalArgumentException("Dodaj co najmniej 2 adresy.");
        if (stops.size()>250) throw new IllegalArgumentException("Maksymalnie 250 adresów na trasę.");
        if (firstId==null || lastId==null || firstId.equals(lastId))
            throw new IllegalArgumentException("Wybierz różne adresy początku i końca.");

        List<Address> list=new ArrayList<>(stops);
        int start=-1,end=-1;
        Set<String> seen=new HashSet<>();
        for (int i=0;i<list.size();i++) {
            Address a=list.get(i);
            if (!seen.add(a.id)) throw new IllegalArgumentException("Powtórzony adres: " + a.label());
            if (a.id.equals(firstId)) start=i;
            if (a.id.equals(lastId)) end=i;
        }
        if (start<0 || end<0) throw new IllegalArgumentException("Początek i koniec muszą być na liście paczek.");

        int n=list.size();
        long[] snapped=new long[n];
        Set<Long> destinationNodes=new HashSet<>();
        for (int i=0;i<n;i++) {
            Address a=list.get(i);
            snapped[i]=graph.nearest(a.lat,a.lon);
            if (snapped[i]!=-1) destinationNodes.add(snapped[i]);
        }
        double[][] dist=new double[n][n];
        boolean[][] isFallback=new boolean[n][n];
        // Ten sam początek drogi może odpowiadać wielu adresom.
        Map<Long,Map<Long,Double>> cache=new HashMap<>();
        for (int i=0;i<n;i++) {
            long id=snapped[i];
            Map<Long,Double> paths = id == -1 ? Collections.emptyMap()
                    : cache.computeIfAbsent(id, from -> graph.distances(from,destinationNodes));
            for (int j=0;j<n;j++) {
                if (i==j) continue;
                Double roadDistance = paths.get(snapped[j]);
                RoadGraph.Coordinate aSnap=graph.position(snapped[i]);
                RoadGraph.Coordinate bSnap=graph.position(snapped[j]);
                double accessA = aSnap==null ? 0 : RoadGraph.meters(list.get(i).lat,list.get(i).lon,aSnap.lat,aSnap.lon);
                double accessB = bSnap==null ? 0 : RoadGraph.meters(list.get(j).lat,list.get(j).lon,bSnap.lat,bSnap.lon);
                if (roadDistance!=null && accessA<=1500 && accessB<=1500) {
                    dist[i][j]=roadDistance + accessA + accessB;
                } else {
                    // Brak połączenia drogowego w importowanym wycinku: przybliżenie,
                    // jawnie zgłaszane w interfejsie. Nie udajemy dokładnego routingu.
                    dist[i][j]=RoadGraph.meters(list.get(i).lat,list.get(i).lon,
                            list.get(j).lat,list.get(j).lon)*3.0 + 2000;
                    isFallback[i][j]=true;
                }
            }
        }
        List<Integer> path=new ArrayList<>();
        path.add(start);
        Set<Integer> remaining=new HashSet<>();
        for (int i=0;i<n;i++) if (i!=start && i!=end) remaining.add(i);
        int cursor=start;
        while (!remaining.isEmpty()) {
            int closest=-1; double best=Double.POSITIVE_INFINITY;
            for (int candidate:remaining) {
                if (dist[cursor][candidate]<best || (dist[cursor][candidate]==best && candidate<closest)) {
                    closest=candidate; best=dist[cursor][candidate];
                }
            }
            path.add(closest); remaining.remove(closest); cursor=closest;
        }
        path.add(end);
        // 2-opt: zachowujemy pierwszą i ostatnią pozycję. Pełna ocena uwzględnia drogi jednokierunkowe.
        int changes=0;
        boolean improved=true;
        while (improved && changes<50) {
            improved=false;
            double baseline=total(path,dist);
            outer: for (int i=1;i<path.size()-2;i++) {
                for (int j=i+1;j<path.size()-1;j++) {
                    Collections.reverse(path.subList(i,j+1));
                    double candidate=total(path,dist);
                    if (candidate+0.1<baseline) {
                        improved=true; changes++; break outer;
                    }
                    Collections.reverse(path.subList(i,j+1));
                }
            }
        }
        List<Address> result=new ArrayList<>();
        boolean fallback=false;
        int count=0;
        for (int i=0;i<path.size();i++) {
            result.add(list.get(path.get(i)));
            if (i>0 && isFallback[path.get(i-1)][path.get(i)]) {
                fallback=true; count++;
            }
        }
        return new Result(result,total(path,dist),fallback,count);
    }

    private static double total(List<Integer> path,double[][] d) {
        double sum=0;
        for (int i=1;i<path.size();i++) sum+=d[path.get(i-1)][path.get(i)];
        return sum;
    }
}
