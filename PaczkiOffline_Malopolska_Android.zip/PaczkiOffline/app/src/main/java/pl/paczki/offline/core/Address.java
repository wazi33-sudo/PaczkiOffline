package pl.paczki.offline.core;

import java.text.Normalizer;
import java.util.Locale;

/** Punkt adresowy OpenStreetMap. */
public final class Address {
    public final String id;
    public final String town;
    public final String street;
    public final String house;
    public final double lat, lon;

    public Address(String id, String town, String street, String house, double lat, double lon) {
        this.id = id;
        this.town = town;
        this.street = street;
        this.house = house;
        this.lat = lat;
        this.lon = lon;
    }

    public String label() {
        if (street == null || street.isEmpty() || normalized(street).equals(normalized(town)))
            return town + " " + house;
        return street + " " + house + ", " + town;
    }

    public static String normalized(String text) {
        return Normalizer.normalize(text == null ? "" : text, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replace('ł', 'l').replace('Ł', 'L')
                .toLowerCase(Locale.ROOT).trim();
    }
}
