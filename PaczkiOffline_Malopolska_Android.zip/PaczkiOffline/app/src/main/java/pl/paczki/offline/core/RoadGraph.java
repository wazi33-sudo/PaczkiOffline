package pl.paczki.offline.core;

import java.util.*;

/** Skierowany graf dróg samochodowych na podstawie tagów OSM. */
public final class RoadGraph {
    public static final class Coordinate {
        public final double lat, lon;
        public Coordinate(double lat, double lon) { this.lat = lat; this.lon = lon; }
    }
    private static final class Edge {
        final long to; final double distance;
        Edge(long to, double distance) { this.to = to; this.distance = distance; }
    }
    private static final class QueueItem {
        final long id; final double distance;
        QueueItem(long id, double distance) { this.id=id; this.distance=distance; }
    }
    private final Map<Long, Coordinate> nodes = new HashMap<>();
    private final Map<Long, List<Edge>> adjacency = new HashMap<>();
    private final Map<Long, List<Long>> grid = new HashMap<>();
    private static final double CELL = 0.004;

    public int size() { return nodes.size(); }

    public static double meters(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2-lat1), dLon = Math.toRadians(lon2-lon1);
        double a = Math.pow(Math.sin(dLat/2),2)
                + Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.pow(Math.sin(dLon/2),2);
        return 6371000.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0,1-a)));
    }

    private static long key(int x, int y) {
        return ((long)x << 32) ^ (y & 0xffffffffL);
    }
    private static int index(double value) { return (int)Math.floor(value / CELL); }

    public void addSegment(long from, Coordinate a, long to, Coordinate b, boolean forward, boolean backward) {
        if (!forward && !backward) return;
        addNode(from, a); addNode(to, b);
        double len = meters(a.lat, a.lon, b.lat, b.lon);
        if (len < 0.01) return;
        if (forward) adjacency.computeIfAbsent(from, unused -> new ArrayList<>()).add(new Edge(to,len));
        if (backward) adjacency.computeIfAbsent(to, unused -> new ArrayList<>()).add(new Edge(from,len));
    }

    private void addNode(long id, Coordinate position) {
        if (nodes.putIfAbsent(id, position) == null) {
            grid.computeIfAbsent(key(index(position.lat), index(position.lon)), unused -> new ArrayList<>()).add(id);
        }
    }

    /** Najbliższy punkt drogi. Przeszukujemy lokalny indeks przestrzenny zamiast wszystkich węzłów. */
    public long nearest(double lat, double lon) {
        if (nodes.isEmpty()) return -1L;
        int x = index(lat), y = index(lon);
        long best = -1L;
        double min = Double.POSITIVE_INFINITY;
        // Każdy promień poszerza przeszukanie. Jeśli coś znaleziono, sprawdzamy jeszcze sąsiedni krąg.
        int foundAt = -1;
        for (int radius=0; radius<=14; radius++) {
            for (int dx=-radius; dx<=radius; dx++) {
                for (int dy=-radius; dy<=radius; dy++) {
                    if (Math.max(Math.abs(dx),Math.abs(dy)) != radius) continue;
                    List<Long> bucket = grid.get(key(x+dx,y+dy));
                    if (bucket == null) continue;
                    for (long id : bucket) {
                        Coordinate point = nodes.get(id);
                        double d = meters(lat,lon,point.lat,point.lon);
                        if (d < min) { min=d; best=id; }
                    }
                }
            }
            if (best != -1L && foundAt == -1) foundAt = radius;
            if (foundAt != -1 && radius >= foundAt+2) return best;
        }
        // Rzadki graf: jeśli nie znaleźliśmy drogi w promieniu kilku kilometrów, sprawdź całość.
        if (best == -1L) {
            for (Map.Entry<Long,Coordinate> e : nodes.entrySet()) {
                Coordinate p = e.getValue();
                double d = meters(lat,lon,p.lat,p.lon);
                if (d < min) { min=d; best=e.getKey(); }
            }
        }
        return best;
    }

    public Coordinate position(long nodeId) { return nodes.get(nodeId); }

    /** Dijkstra z zakończeniem, gdy poznaliśmy wszystkie poszukiwane węzły. */
    public Map<Long, Double> distances(long start, Set<Long> targets) {
        Map<Long,Double> dist = new HashMap<>();
        if (start == -1L) return dist;
        Set<Long> remaining = new HashSet<>(targets);
        PriorityQueue<QueueItem> q = new PriorityQueue<>(Comparator.comparingDouble(v -> v.distance));
        dist.put(start, 0.0); q.add(new QueueItem(start, 0.0));
        while (!q.isEmpty() && !remaining.isEmpty()) {
            QueueItem curr = q.poll();
            if (curr.distance > dist.getOrDefault(curr.id, Double.POSITIVE_INFINITY)) continue;
            remaining.remove(curr.id);
            for (Edge edge: adjacency.getOrDefault(curr.id, Collections.emptyList())) {
                double next = curr.distance + edge.distance;
                if (next < dist.getOrDefault(edge.to, Double.POSITIVE_INFINITY)) {
                    dist.put(edge.to, next);
                    q.add(new QueueItem(edge.to, next));
                }
            }
        }
        return dist;
    }
}
