from xml.etree.ElementTree import Element, SubElement, ElementTree, indent
from pathlib import Path
out=Path(__file__).resolve().parent.parent/'sample_data'/'PRZYKLAD_TESTOWY.osm'
root=Element('osm', version='0.6', generator='TEST (dane fikcyjne, nie prawdziwe OpenStreetMap)')
for i, city, lat, lon in [(99900, 'Testowo', 50.0, 20.0),(99901,'Próbna Wieś', 50.001,20.008)]:
    n=SubElement(root, 'node',id=str(i),lat=str(lat),lon=str(lon))
    SubElement(n,'tag',k='place',v='village')
    SubElement(n,'tag',k='name',v=city)
# Siatka dróg i adresów (fikcyjne; nie używać do prawdziwych dostaw).
nodeid=100000
roads={}
for r in range(4):
    for c in range(6):
        nid=nodeid+r*6+c
        lat=50+r*0.0009; lon=20+c*0.0018
        roads[(r,c)]=nid
        SubElement(root,'node',id=str(nid),lat=str(lat),lon=str(lon))
for k,(r,c) in enumerate([(0,0),(0,2),(0,4),(1,1),(1,4),(2,0),(2,3),(2,5),(3,1),(3,3),(3,5),(0,5)]):
    city='Testowo' if c<3 else 'Próbna Wieś'
    n=SubElement(root,'node',id=str(200000+k),lat=str(50+r*0.0009+0.00016),lon=str(20+c*0.0018+0.00015))
    for a,b in [('addr:city',city),('addr:street','Główna' if r<2 else 'Polna'),('addr:housenumber',str(k+1))]:
        SubElement(n,'tag',k=a,v=b)
wid=300000
for r in range(4):
    w=SubElement(root,'way',id=str(wid));wid+=1
    for c in range(6): SubElement(w,'nd',ref=str(roads[(r,c)]))
    SubElement(w,'tag',k='highway',v='residential')
    if r==2: SubElement(w,'tag',k='oneway',v='yes')
for c in range(6):
    w=SubElement(root,'way',id=str(wid));wid+=1
    for r in range(4): SubElement(w,'nd',ref=str(roads[(r,c)]))
    SubElement(w,'tag',k='highway',v='residential')
# Osobny budynek z adresem jako way (parser ma to też uwzględniać)
for k,(r,c) in enumerate([(0,0),(0,1),(1,1),(1,0)]):
    n=SubElement(root,'node',id=str(500001+k),lat=str(50+r*0.00015+0.003),lon=str(20+c*0.00015+0.005))
w=SubElement(root,'way',id='600000')
for nid in (500001,500002,500003,500004,500001): SubElement(w,'nd',ref=str(nid))
for a,b in [('building','yes'),('addr:city','Próbna Wieś'),('addr:street','Nowa'),('addr:housenumber','20A')]:
    SubElement(w,'tag',k=a,v=b)
indent(root)
ElementTree(root).write(out,encoding='utf-8',xml_declaration=True)
print(out)
