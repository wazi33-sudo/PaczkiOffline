"""Smoke-test bundle produced by prepare_malopolska.py with the tiny fixture."""
import gzip
from pathlib import Path
import sqlite3
import sys
import tempfile

package=Path(sys.argv[1])
with tempfile.TemporaryDirectory() as td:
    dbpath=Path(td)/'test.db'
    with gzip.open(package,'rb') as stream, dbpath.open('wb') as out:
        for chunk in iter(lambda:stream.read(1024*1024),b''):out.write(chunk)
    db=sqlite3.connect(dbpath)
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert db.execute('SELECT value FROM metadata WHERE key="format_version"').fetchone()[0]=='1'
    assert db.execute('SELECT COUNT(*) FROM addresses').fetchone()[0]==13
    assert db.execute('SELECT COUNT(DISTINCT town) FROM addresses').fetchone()[0]==2
    assert db.execute('SELECT COUNT(*) FROM road_nodes').fetchone()[0]>0
    assert db.execute('SELECT COUNT(*) FROM road_edges').fetchone()[0]>0
    address=db.execute("SELECT id,label FROM addresses WHERE town=? AND search LIKE ? ESCAPE '\\'", ('Testowo','%polna 9%')).fetchall()
    assert len(address)==1,address
    # Test SQL used by Android with one/two city bounds and road edge lookup.
    boxes=[(49,51,19,22),(49,51,21,23)]
    where=' OR '.join('(lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?)' for _ in boxes)
    args=[str(x) for box in boxes for x in box]
    assert db.execute('SELECT COUNT(*) FROM road_nodes WHERE '+where,args).fetchone()[0]>0
    assert db.execute('SELECT COUNT(*) FROM road_edges e WHERE e.source IN (SELECT id FROM road_nodes WHERE '+where+')',args).fetchone()[0]>0
    print('OK: archiwum SQLite, 13 adresów, 2 miejscowości, indeks wyszukiwania i sieć dróg.')
