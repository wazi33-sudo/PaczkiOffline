import java.io.*;
import java.util.*;
import pl.paczki.offline.core.*;

public class CoreTest {
    public static void main(String[] argv) throws Exception {
        OsmParser.Data data;
        try (InputStream in=new FileInputStream(argv[0])) { data=OsmParser.read(in); }
        require(data.addresses.size()==13,"13 adresów z node i way: " + data.addresses.size());
        require(data.towns().size()==2,"dwie miejscowości");
        require(data.graph.size()==24,"24 węzły dróg");
        require(data.addresses.stream().anyMatch(a -> a.house.equals("20A")),"adres budynku jako way");
        Address first=data.addresses.get(3), last=data.addresses.get(8);
        RoutePlanner.Result r=RoutePlanner.plan(data.addresses,first.id,last.id,data.graph);
        require(r.ordered.size()==13,"13 punktów trasy");
        require(r.ordered.get(0).id.equals(first.id),"stały początek");
        require(r.ordered.get(r.ordered.size()-1).id.equals(last.id),"stały koniec");
        require(r.estimatedMeters>0,"dodatnia odległość");
        HashSet<String> ids = new HashSet<>();
        for (Address a:r.ordered) require(ids.add(a.id),"bez powtórzeń");
        try { RoutePlanner.plan(data.addresses,first.id,first.id,data.graph); throw new AssertionError("Miał być błąd"); }
        catch (IllegalArgumentException expected) {}
        RoadGraph directed=new RoadGraph();
        RoadGraph.Coordinate p1=new RoadGraph.Coordinate(50.0,20.0);
        RoadGraph.Coordinate p2=new RoadGraph.Coordinate(50.0,20.001);
        directed.addSegment(1L,p1,2L,p2,true,false);
        require(directed.distances(1L,Set.of(2L)).get(2L)>0,"droga jednokierunkowa w przód");
        require(!directed.distances(2L,Set.of(1L)).containsKey(1L),"brak przejazdu pod prąd");
        System.out.println("OK: parsowanie OSM, 2 miejscowości, drogi jednokierunkowe, budynki i stały początek/koniec");
        System.out.println("Adresy: "+data.addresses.size()+", drogi: "+data.graph.size()+", dystans: "+Math.round(r.estimatedMeters)+" m");
        for (int i=0;i<r.ordered.size();i++) System.out.println((i+1)+". "+r.ordered.get(i).label());
    }
    static void require(boolean cond,String name) { if (!cond) throw new AssertionError("Nieprawidłowe: "+name); }
}
