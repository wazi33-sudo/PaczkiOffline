# Paczki Offline — MAŁOPOLSKA (Android)

Aplikacja do sortowania paczek kurierskich **offline** z adresami OpenStreetMap dla całego województwa małopolskiego.

## Co robi

- Dane Małopolski są **wbudowane do APK podczas jego budowania** (nie trzeba pobierać danych na telefonie).
- Wybierasz jedną lub dwie miejscowości, wyszukujesz i dodajesz numery domów.
- Ustawiasz adres **pierwszej** i **ostatniej** paczki.
- Aplikacja układa kolejność doręczeń według dróg OSM; zalecenie: paczki wkłada się do samochodu **od końca** otrzymanej listy.
- Po instalacji i pierwszym rozpakowaniu bazy działa offline: bez internetu, bez GPS, bez konta i bez mapy na ekranie.
- Maksymalnie 250 różnych adresów na trasę, duplikaty paczek do jednego domu traktowane jako jeden punkt.

**Źródło:** Geofabrik, wycinek `malopolskie-latest.osm.pbf` z https://download.geofabrik.de/europe/poland/malopolskie.html. Geofabrik udostępnia go jako ok. 193 MB PBF (wielkość zmienia się). Skrypt przekształca go w bazę SQLite i pakuje jako `app/src/main/assets/malopolska.db.gz`. To baza adresów oraz dróg, nie obraz mapy.

## Jak otrzymać APK

### Opcja 1 — GitHub Actions (budowanie automatyczne)

1. Umieść **całą zawartość folderu** `PaczkiOffline` w nowym repozytorium GitHub, zachowując strukturę podfolderów, w tym `.github/workflows/`.
2. Wejdź do zakładki **Actions** i wybierz **Zbuduj APK Android - Małopolska offline** → **Run workflow**. W repozytorium z gałęzią `main`/`master` budowanie uruchamia się także po przesłaniu plików.
3. Praca pobierze plik Geofabrik (około 193 MB), przygotuje bazę offline, dołączy ją do APK, skompiluje i podpisze debugowo.
4. Po zakończeniu w **Artifacts** pojawi się `PaczkiOffline-Malopolska-APK`. Pobierz, rozpakuj, wyślij `app-debug.apk` na telefon i zainstaluj.

**Wymagane jest połączenie z internetem na komputerze/serwerze jedynie podczas budowania; telefon później działa offline.** Nie instaluj APK z niezaufanych repozytoriów.

### Opcja 2 — Android Studio + Python na komputerze

Wymagania: Python 3.10+, `pip install osmium`, Android Studio z SDK 35, JDK 17, Gradle 8.11.1.

```bash
python -m pip install osmium
python tools/prepare_malopolska.py
gradle :app:assembleDebug
```

Plik APK: `app/build/outputs/apk/debug/app-debug.apk`.

Jeżeli masz już pobrany plik PBF:

```bash
python tools/prepare_malopolska.py --input /sciezka/malopolskie-latest.osm.pbf
```

**Nie buduj projektu bez uprzedniego uruchomienia skryptu**, bo braknie wbudowanych danych Małopolski. Projekt nie zawiera w ZIP-ie pełnego zbioru OSM — powstaje on w procesie budowania APK.

## Weryfikacja programu bez internetu i Android SDK

Test algorytmu Java dla 13 fikcyjnych adresów:

```bash
mkdir -p out
javac -encoding UTF-8 -d out app/src/main/java/pl/paczki/offline/core/*.java tests/CoreTest.java
java -cp out CoreTest sample_data/PRZYKLAD_TESTOWY.osm
```

Test małego przetworzonego wycinka do SQLite:

```bash
python tools/prepare_malopolska.py --input sample_data/PRZYKLAD_TESTOWY.osm --output sample_data/fixture.db.gz
```

Dane `sample_data` są fikcyjne — **nie** są mapą Małopolski. Przekazany projekt nie był kompilowany ani uruchamiany na fizycznym urządzeniu z Androidem; skrypt generowania bazy został przetestowany tylko na małym przykładowym pliku OSM, nie na pełnym PBF.

## Ograniczenia

- Brak adresu w danych OSM = nie ma go na liście. W części miejscowości mogą występować braki, błędne numery oraz niejednoznaczne nazwy. Miejscowości o identycznych nazwach mogą być połączone na jednej liście.
- Nie jest to nawigacja ani gwarancja najkrótszej trasy: nie uwzględnia korków, zakazów skrętów, aktualnych objazdów, ograniczeń tonażowych oraz wszystkich reguł dostępu. Uwzględnia część dróg jednokierunkowych i podstawowe typy dróg samochodowych.
- Dla bardzo dużego obszaru z ponad 130 tys. węzłów drogowych wczytywanej sieci aplikacja stosuje odległości przybliżone zamiast ryzykować błąd pamięci; pojawi się ostrzeżenie.
- Pierwsze uruchomienie na telefonie kopiuje i rozpakowuje bazę do pamięci aplikacji. Trzeba mieć miejsce na APK **i** rozpakowaną bazę danych.
- Baza danych wewnątrz APK jest stała — aktualizacja wymaga nowego APK wygenerowanego z aktualnego pakietu Geofabrik.

## Licencje

Dane OpenStreetMap: © współtwórcy OpenStreetMap, Open Database License (ODbL): https://www.openstreetmap.org/copyright

Pakiet źródłowy `Paczki Offline`: patrz plik LICENSE.
